import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib
matplotlib.rcParams['mathtext.fontset'] = 'dejavuserif'
matplotlib.rc('xtick', labelsize=12)
matplotlib.rc('ytick', labelsize=12)
matplotlib.rcParams.update({'font.size': 12})
matplotlib.rcParams['font.family'] = 'serif'
from numpy.linalg import eigh, inv
from scipy.optimize import minimize
import os
os.chdir('c:/users/gugli/desktop/tesi/codice')
from functions import *
from time import time
timezero = time()

##values
print('Defining/importing numerical values \n')

#lattice parameter [hbar*c/eV]
lp = 2.466731e-10/1.97327e-7
#lattice step [hbar*c/eV]
a = lp/np.sqrt(3)
#lattice parameter/lattice step conversion factor * 2pi
conv_lattice = 2*np.pi/np.sqrt(3)
#carbon atom mass [eV/c^2]
M = 12*1.66054e-27/1.78266192e-36
#best fit parameters for electron bands [eV]
pp_el = np.load('c:/users/gugli/desktop/tesi/data/bande_bestfit.npy')
#best fit parameters for phonon lines [eV^2]
pp_ph = np.load(r'c:/users/gugli/desktop/tesi/data/phonons_bestfit.npy')
#gamma parameters [hbar^2 c^2 / eV^2]
gamma = np.load(r'c:/users/gugli/desktop/tesi/data/gamma.npy')
gamma_mat = np.array([np.array([gamma[0], gamma[1]]), np.array([gamma[1], gamma[0]])])
gamma_mat = gamma_mat*1e20*(1.97327e-7)**2
#FBZ meshgrid [1/a]
fbz = np.load(r'c:/users/gugli/desktop/tesi/data/fbz_meshgrid.npy')
#differential [1/a]
dkx = 2*np.pi/3/np.sqrt(len(fbz))/10
dky = 2*np.pi/np.sqrt(3)/np.sqrt(len(fbz))/10
dk = [dkx, dky]

#high-symmetry contour
#number of points in the contour
times = 1
lenMG = 30*times
lenGK = 41*times
lenKM = 20*times
#high symmetry contour
qxMG = np.linspace(2*np.pi/3, 0, lenMG)
qyMG = np.zeros(lenMG)
qxGK = np.linspace(0, 2*np.pi/3, lenGK)
qyGK = 1/np.sqrt(3)*qxGK
qyKM = np.linspace(2*np.pi/3/np.sqrt(3),0, lenKM)
qxKM = 2*np.pi/3*np.ones(lenKM)

qindGK = np.sqrt(qxGK**2+qyGK**2)/conv_lattice
qindKM = qindGK[-1] + np.flip(qyKM)/conv_lattice
qindMG = qindKM[-1] + np.flip(qxMG)/conv_lattice

qqx = np.concatenate((qxGK, qxKM, qxMG))
qqy = np.concatenate((qyGK, qyKM, qyMG))

qind = np.concatenate((qindGK, qindKM, qindMG))

for i in range(len(qind)):
    qind[i] = round(qind[i], 4)

qq = np.array([qqx, qqy])
qq = np.transpose(qq)

##evaluation

print('Evaluating relevant quantities \n')

print('Save data? \n')
save = input()
save_data = False
if save == 'y':
    save_data = True
if save_data:
    print('Saving data')

start = time()
#initialize variables with the right dimensions
#E(k), u(k), P(k)
ek = np.zeros((len(fbz), 2)); uk = np.zeros((len(fbz), 2,2), dtype = 'complex'); pk = np.zeros((len(fbz), 2, 2, 2), dtype = 'complex')
#E(-k), u(-k), P(-k)
emk = np.zeros((len(fbz), 2)); umk = np.zeros((len(fbz), 2,2), dtype = 'complex'); pmk = np.zeros((len(fbz), 2, 2, 2), dtype = 'complex')
#E(k-q), u(k-q), P(k-q)
ekmq = np.zeros((len(qq), len(fbz), 2)); ukmq = np.zeros((len(qq), len(fbz),2,2), dtype = 'complex'); pkmq = np.zeros((len(qq), len(fbz), 2, 2, 2), dtype = 'complex')
#E(k+q), u(k+q), P(k+q)
ekpq = np.zeros((len(qq), len(fbz), 2)); ukpq = np.zeros((len(qq), len(fbz),2,2), dtype = 'complex'); pkpq = np.zeros((len(qq), len(fbz), 2, 2, 2), dtype = 'complex')
#E(q-k), u(q-k), P(q-k)
eqmk = np.zeros((len(qq), len(fbz), 2)); uqmk = np.zeros((len(qq), len(fbz),2,2), dtype = 'complex'); pqmk = np.zeros((len(qq), len(fbz), 2, 2, 2), dtype = 'complex')
#E(-k-q), u(-k-q), P(-k-q)
emkmq = np.zeros((len(qq), len(fbz), 2)); umkmq = np.zeros((len(qq), len(fbz),2,2), dtype = 'complex'); pmkmq = np.zeros((len(qq), len(fbz), 2, 2, 2), dtype = 'complex')
#dE(k), dP(k)
dek = np.zeros((len(fbz), 2, 2), dtype = 'complex'); dpk = np.zeros((len(fbz), 2, 2, 2, 2), dtype = 'complex')
#dE(-k), dP(-k)
demk = np.zeros((len(fbz), 2, 2), dtype = 'complex'); dpmk = np.zeros((len(fbz), 2, 2, 2, 2), dtype = 'complex')
#dE(k-q), dP(k-q)
dekmq = np.zeros((len(qq), len(fbz), 2, 2), dtype = 'complex'); dpkmq = np.zeros((len(qq), len(fbz), 2, 2, 2, 2), dtype = 'complex')
#dE(k+q), dP(k+q)
dekpq = np.zeros((len(qq), len(fbz), 2, 2), dtype = 'complex'); dpkpq = np.zeros((len(qq), len(fbz), 2, 2, 2, 2), dtype = 'complex')
#dE(-k-q), dP(-k-q)
demkmq = np.zeros((len(qq), len(fbz), 2, 2), dtype = 'complex'); dpmkmq = np.zeros((len(qq), len(fbz), 2, 2, 2, 2), dtype = 'complex')
#dE(q-k), dP(q-k)
deqmk = np.zeros((len(qq), len(fbz), 2, 2), dtype = 'complex'); dpqmk = np.zeros((len(qq), len(fbz), 2, 2, 2, 2), dtype = 'complex')
#ddE(k), ddP(k)
ddek = np.zeros((len(fbz), 2, 2, 2), dtype = 'complex'); ddpk = np.zeros((len(fbz), 2, 2, 2, 2, 2), dtype = 'complex')
#ddE(q-k), ddP(q-k)
ddeqmk = np.zeros((len(qq), len(fbz), 2, 2, 2), dtype = 'complex'); ddpqmk = np.zeros((len(qq), len(fbz), 2, 2, 2, 2, 2), dtype = 'complex')

print('Evaluating and vectorizing relevant quantities \n')
#cycle on the FBZ
for k_ind in range(len(fbz)):
    k = fbz[k_ind,:]
    ek[k_ind], uk[k_ind], pk[k_ind] = EUP(k, pp_el)
    ek[k_ind] = ek[k_ind] - pp_el[0]
    emk[k_ind], umk[k_ind], pmk[k_ind] = EUP(-k, pp_el)
    dek[k_ind], dpk[k_ind] = dEdP(k, pp_el, dk)
    demk[k_ind], dpmk[k_ind] = dEdP(-k, pp_el, dk)
    ddek[k_ind], ddpk[k_ind] = dEdP(k, pp_el, dk)
    #cycle on the high-symmetry contour
    for q_ind in range(len(qq)):
        q = qq[q_ind,:]
        ekmq[q_ind, k_ind], ukmq[q_ind, k_ind], pkmq[q_ind, k_ind] = EUP(k-q, pp_el)
        ekpq[q_ind, k_ind], ukpq[q_ind, k_ind], pkpq[q_ind, k_ind] = EUP(k+q, pp_el)
        eqmk[q_ind, k_ind], uqmk[q_ind, k_ind], pqmk[q_ind, k_ind] = EUP(q-k, pp_el)
        emkmq[q_ind, k_ind], umkmq[q_ind, k_ind], pmkmq[q_ind, k_ind] = EUP(-k-q, pp_el)
        ekmq[q_ind, k_ind] = ekmq[q_ind, k_ind] - pp_el[0]
        ekpq[q_ind, k_ind] = ekpq[q_ind, k_ind] - pp_el[0]
        eqmk[q_ind, k_ind] = eqmk[q_ind, k_ind] - pp_el[0]
        emkmq[q_ind, k_ind] = emkmq[q_ind, k_ind]-pp_el[0]
        dekmq[q_ind, k_ind], dpkmq[q_ind, k_ind] = dEdP(k-q, pp_el, dk)
        dekpq[q_ind, k_ind], dpkpq[q_ind, k_ind] = dEdP(k+q, pp_el, dk)
        demkmq[q_ind, k_ind], dpmkmq[q_ind, k_ind] = dEdP(-k-q, pp_el, dk)
        deqmk[q_ind, k_ind], dpqmk[q_ind, k_ind] = dEdP(q-k, pp_el, dk)
        ddeqmk[q_ind, k_ind], ddpqmk[q_ind, k_ind] = ddEddP(q-k, pp_el, dk)
    print('%.2f'%(k_ind/len(fbz)))

print('Time for evaluation: %.1f min'%((time()-start)/60))

##calculation

print('Calculating tensors\n')
start = time()

#initialize F tensors [qind, kind, tau, i]
fEkkmq = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fGkkmq = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fEkmqk = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fGkmqk = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fEkkpq = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fGkkpq = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fEkpqk = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
fGkpqk = np.zeros((len(qq),len(fbz),2,2), dtype = 'complex')
#initialize m tensors [(qind,) kind, tau1, tau2, i, j]
mEGk = np.zeros((len(fbz), 2,2,2,2), dtype = 'complex')
mEGqmk = np.zeros((len(qq),len(fbz),2,2,2,2), dtype = 'complex')
mGk = np.zeros((len(fbz), 2,2,2,2), dtype = 'complex')
mGqmk = np.zeros((len(qq),len(fbz),2,2,2,2), dtype = 'complex')

#calculate F/M tensors
#cycle on the FBZ meshgrid
for k_ind in range(len(fbz)):
    #cycle on M tensors indices
    for tau1 in range(2):
        for tau2 in range(2):
            for i in range(2):
                for j in range(2):
                    #sum on mute index
                    for nux in range(2):
                        mEGk[k_ind, tau1, tau2, i, j] += -gamma_mat[tau1, tau2]**2*(dek[k_ind, i, nux]*dpk[k_ind, j, nux, tau1, tau2] + dek[k_ind, j, nux]*dpk[k_ind, i, nux, tau1, tau2])
                        mGk[k_ind, tau1, tau2, i, j] += - gamma_mat[tau1, tau2]**2*ek[k_ind, nux]*ddpk[k_ind, i,j,nux, tau1, tau2]
    #cycle on the high-symmetry contour
    for q_ind in range(len(qq)):
        #cycle on M tensors indices
        for tau1 in range(2):
            for tau2 in range(2):
                for i in range(2):
                    for j in range(2):
                        #sum on mute index
                        for nux in range(2):
                            mEGqmk[q_ind,k_ind, tau1, tau2, i, j] += -gamma_mat[tau1, tau2]**2*(deqmk[q_ind, k_ind, i, nux]*dpqmk[q_ind,k_ind, j, nux, tau1, tau2] + deqmk[q_ind,k_ind, j, nux]*dpqmk[q_ind,k_ind, i, nux, tau1, tau2])
                            mGqmk[q_ind, k_ind, tau1, tau2, i, j] += - gamma_mat[tau1, tau2]**2*eqmk[q_ind, k_ind, nux]*ddpqmk[q_ind, k_ind, i, j, nux, tau1, tau2]
        #cycle on F tensors indices
        for tau in range(2):
            for i in range(2):
                #sum on mute indices
                for taux in range(2):
                    for nux in range(2):
                        fEkkmq[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(dek[k_ind, i, nux]*ukmq[q_ind, k_ind, 1, tau]*pk[k_ind, nux, tau, taux]*np.conj(uk[k_ind, 0, taux]) + deqmk[q_ind, k_ind, i, nux]*np.conj(uk[k_ind, 0, tau])*pqmk[q_ind, k_ind, nux, tau, taux]*ukmq[q_ind, k_ind, 1, taux])
                        fEkmqk[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(dekmq[q_ind, k_ind, i, nux]*uk[k_ind, 0, tau]*pkmq[q_ind, k_ind, nux, tau, taux]*np.conj(ukmq[q_ind, k_ind, 1, taux]) + demk[k_ind, i, nux]*np.conj(ukmq[q_ind, k_ind, 1, tau])*pmk[k_ind, nux, tau, taux]*uk[k_ind, 0, taux])
                        fEkkpq[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(dek[k_ind, i, nux]*ukpq[q_ind, k_ind, 1, tau]*pk[k_ind, nux, tau, taux]*np.conj(uk[k_ind, 0, taux]) + demkmq[q_ind, k_ind, i, nux]*np.conj(uk[k_ind, 0, tau])*pmkmq[q_ind, k_ind, nux, tau, taux]*ukpq[q_ind, k_ind, 1, taux])
                        fEkpqk[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(dekpq[q_ind, k_ind, i, nux]*uk[k_ind, 0, tau]*pkpq[q_ind, k_ind, nux, tau, taux]*np.conj(ukpq[q_ind, k_ind, 1, taux]) + demk[k_ind, i, nux]*np.conj(ukpq[q_ind, k_ind, 1, tau])*pmk[k_ind, nux, tau, taux]*uk[k_ind, 0, taux])
                        fGkkmq[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(ek[k_ind, nux]*ukmq[q_ind, k_ind, 1, tau]*dpk[k_ind, i, nux, tau, taux]*np.conj(uk[k_ind, 0, taux]) + eqmk[q_ind, k_ind,  nux]*np.conj(uk[k_ind, 0, tau])*dpqmk[q_ind, k_ind, i, nux, tau, taux]*ukmq[q_ind, k_ind, 1, taux])
                        fGkmqk[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(ekmq[q_ind, k_ind, nux]*uk[k_ind, 0, tau]*dpkmq[q_ind, k_ind, i, nux, tau, taux]*np.conj(ukmq[q_ind, k_ind, 1, taux]) + emk[k_ind,  nux]*np.conj(ukmq[q_ind, k_ind, 1, tau])*dpmk[k_ind, i,  nux, tau, taux]*uk[k_ind, 0, taux])
                        fGkkpq[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(ek[k_ind, nux]*ukpq[q_ind, k_ind, 1, tau]*dpk[k_ind, i, nux, tau, taux]*np.conj(uk[k_ind, 0, taux]) + emkmq[q_ind, k_ind, nux]*np.conj(uk[k_ind, 0, tau])*dpmkmq[q_ind, k_ind, i, nux, tau, taux]*ukpq[q_ind, k_ind, 1, taux])
                        fGkpqk[q_ind, k_ind, tau, i] += 1j*gamma_mat[tau, taux]*(ekpq[q_ind, k_ind, nux]*uk[k_ind, 0, tau]*dpkpq[q_ind, k_ind, i, nux, tau, taux]*np.conj(ukpq[q_ind, k_ind, 1, taux]) + emk[k_ind, nux]*np.conj(ukpq[q_ind, k_ind, 1, tau])*dpmk[k_ind, i, nux, tau, taux]*uk[k_ind, 0, taux])
    print('%.2f'%(k_ind/len(fbz)))

print('Calculating matrix elements')
#calculate dynamical matrix elements
Dgeo = []
#cycle on the high-symmetry contour
for q_ind in range(len(qq)):
    DG = np.zeros((2,2,2,2), dtype = 'complex')
    #cycle on DM indices
    for tau1 in range(2):
        for tau2 in range(2):
            for i in range(2):
                for j in range(2):
                    #sum on the FBZ
                    for k_ind in range(len(fbz)):
                        DG[tau1, tau2, i, j] += fGkkmq[q_ind, k_ind, tau1, i]*fGkmqk[q_ind, k_ind, tau2, j]/(ek[k_ind,0]-ekmq[q_ind, k_ind, 1]) + fGkkpq[q_ind, k_ind, tau2, j]*fGkpqk[q_ind, k_ind, tau1, i]/(ek[k_ind,0]-ekpq[q_ind, k_ind, 1])
                        DG[tau1, tau2, i, j] += fGkkmq[q_ind, k_ind, tau1, i]*fEkmqk[q_ind, k_ind, tau2, j]/(ek[k_ind,0]-ekmq[q_ind, k_ind, 1]) + fGkkpq[q_ind, k_ind, tau2, j]*fEkpqk[q_ind, k_ind, tau1, i]/(ek[k_ind,0]-ekpq[q_ind, k_ind, 1])
                        DG[tau1, tau2, i, j] += fEkkmq[q_ind, k_ind, tau1, i]*fGkmqk[q_ind, k_ind, tau2, j]/(ek[k_ind,0]-ekmq[q_ind, k_ind, 1]) + fEkkpq[q_ind, k_ind, tau2, j]*fGkpqk[q_ind, k_ind, tau1, i]/(ek[k_ind,0]-ekpq[q_ind, k_ind, 1])
                        DG[tau1, tau2, i, j] += - mEGqmk[q_ind, k_ind,tau1, tau2, i,j]*pk[k_ind, 0, tau2, tau1]
                        DG[tau1, tau2, i, j] += - mGqmk[q_ind, k_ind, tau1, tau2, i,j]*pk[k_ind, 0, tau2, tau1]
                        if (tau1 == tau2):
                            for taux in range(2):
                                DG[tau1, tau1, i, j] += mEGk[k_ind,tau1, taux, i, j]*pk[k_ind, 0, taux, tau1]
                                DG[tau1, tau1, i, j] += mGk[k_ind,tau1, taux, i, j]*pk[k_ind, 0, taux, tau1]
    DGblock = np.block([[DG[0,0], DG[0,1]], [DG[1,0],
 DG[1,1]]])
    DGblock = DGblock/M/len(fbz)
    Dgeo.append(DGblock)
    print('%.2f'%(q_ind/len(qq)))

if save_data:
    np.save('c:/users/gugli/desktop/tesi/data/Dgeo.npy', Dgeo)

print('Time for calculation: %.1f min\n'%((time()-start)/60))
print('Total computation time: %.1f min\n'%((time()-timezero)/60))