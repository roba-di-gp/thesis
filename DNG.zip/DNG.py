import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib
matplotlib.rcParams['mathtext.fontset'] = 'dejavuserif'
matplotlib.rc('xtick', labelsize=12)
matplotlib.rc('ytick', labelsize=12)
matplotlib.rcParams.update({'font.size': 12})
matplotlib.rcParams['font.family'] = 'serif'
from numpy.linalg import eigh, inv
from scipy.optimize import minimize
import os
os.chdir('c:/users/gugli/desktop/tesi/codice')
from functions import *

#hbar [eV s]
hbar = 6.582119569e-16
#lattice parameter/lattice step conversion factor * 2pi
conv_lattice = 2*np.pi/np.sqrt(3)
#conversion from cm^-1 to eV
conv = 0.00012398
#from cm^-2 to meV^2
conv2 = conv**2

#geometric term in the dynamical matrix [eV^2]
Dgeo = np.load('c:/users/gugli/desktop/tesi/data/Dgeo.npy')

#number of points in the contour
times = int(len(Dgeo)/91)
lenMG = 30*times
lenGK = 41*times
lenKM = 20*times
#high symmetry contour
kxMG = np.linspace(2*np.pi/3, 0, lenMG)
kyMG = np.zeros(lenMG)
kxGK = np.linspace(0, 2*np.pi/3, lenGK)
kyGK = 1/np.sqrt(3)*kxGK
kyKM = np.linspace(2*np.pi/3/np.sqrt(3),0, lenKM)
kxKM = 2*np.pi/3*np.ones(lenKM)

kindGK = np.sqrt(kxGK**2+kyGK**2)/conv_lattice
kindKM = kindGK[-1] + np.flip(kyKM)/conv_lattice
kindMG = kindKM[-1] + np.flip(kxMG)/conv_lattice

kkx = np.concatenate((kxGK, kxKM, kxMG))
kky = np.concatenate((kyGK, kyKM, kyMG))

kind = np.concatenate((kindGK, kindKM, kindMG))

ticks = [0, 0.6666, 1., 1.5774]
ticklabels = ['$\Gamma$','K', 'M', '$\Gamma$']

for i in range(len(kind)):
    kind[i] = round(kind[i], 4)

kk = np.array([kkx, kky])
kk = np.transpose(kk)

pp = np.load(r'c:/users/gugli/desktop/tesi/data/phonons_bestfit.npy')

#calculate the dispersion on the high-symmetry contour
Eout = []
Ein = []
for i in range(len(kk)):
    eout = ph_z(kk[i], pp)
    ein, null = ph_xy(kk[i], pp)
    Eout.append(eout)
    Ein.append(ein)

Ein_ng = []
Dng = []
D = []
for i in range(len(kk)):
    ein_ng, d, dng = ph_xy_NG(kk[i], pp, Dgeo[i])
    Dng.append(dng)
    D.append(d)
    Ein_ng.append(ein_ng)

#convert to numpy array (easier to plot)
Eout = np.array(Eout)
Ein = np.array(Ein)
Ein_ng = np.array(Ein_ng)

#convert to meV
lines = np.array([Eout[:,0], Eout[:,1], Ein[:,0], Ein[:,1], Ein[:,2], Ein[:,3]])*1e3
lines_ng = np.array([Ein_ng[:,0],Ein_ng[:,1],Ein_ng[:,2],Ein_ng[:,3]])*1e3

#plot modes
my_dpi = 96
fig1, ax1 = plt.subplots(1, figsize=(650/my_dpi, 400/my_dpi), dpi=my_dpi)

my_lw = 1.2
my_ms = 2.5

for i in range(5):
    plt.plot(kind, lines[i,:], 'k-', linewidth=my_lw, zorder=2)
for i in range(4):
    plt.plot(kind, lines_ng[i,:], 'r--', linewidth=my_lw, zorder=2)

plt.plot(kind, lines[5][:], 'k-', linewidth=my_lw, zorder=2, label='With geometry')
plt.plot(kind, lines_ng[3][:], 'r--', linewidth=my_lw, zorder=2, label='Without geometry')

#figure details
ticks = [0, 0.6666, 1., 1.5774]
ticklabels = ['$\Gamma$','K', 'M', '$\Gamma$']
plt.xticks(ticks, ticklabels)
plt.ylabel('Phonon energy  [meV]')
plt.subplots_adjust(left=0.2, right=0.8, bottom = 0.2, top = 0.9)
plt.legend(shadow=True, loc = (0.35,0.05), prop={'size': 8})
plt.grid(axis = 'x', linestyle = '--', alpha = 0.6, zorder = -5)
my_fs = 9
#convert to meV
conv = conv*1e3
plt.text(4./conv_lattice, conv*1550, 'LO', fontsize=my_fs)
plt.text(1.4/conv_lattice, conv*1550, 'LO', fontsize=my_fs)
plt.text(4.9/conv_lattice, conv*1390, 'TO', fontsize=my_fs)
plt.text(0.6/conv_lattice, conv*1370, 'TO', fontsize=my_fs)
plt.text(4.5/conv_lattice, conv*1000, 'LA', fontsize=my_fs)
plt.text(1./conv_lattice, conv*1000, 'LA', fontsize=my_fs)
plt.text(1.05/conv_lattice, conv*360, 'TA', fontsize=my_fs)
plt.text(4.3/conv_lattice, conv*360, 'TA', fontsize=my_fs)
plt.text(0.1/conv_lattice, conv*940, 'ZO', fontsize=my_fs)
plt.text(5.3/conv_lattice, conv*940, 'ZO', fontsize=my_fs)
plt.text(1.2/conv_lattice, conv*110, 'ZA', fontsize=my_fs)
plt.text(4.2/conv_lattice, conv*110, 'ZA', fontsize=my_fs)

plt.xlim(0, 1.5774)
#plt.ylim(0, 210)
plt.savefig('c:/users/gugli/desktop/tesi/figure/phonons_ng.jpeg', dpi = my_dpi*5)

plt.show()